
const PRODUCT_ACTION_ICONS =  [
      {
        icon : 'fa fa-shopping-cart',
        route : '/cart'
      },
      {
        icon : 'fa fa-heart',
        // route : '/favorite'
      },
      {
        icon : 'fa fa-sync-alt',
        route : ''
      },
      { 
        icon : 'fa fa-search',
        route : '/shop-detail'
      },
    ];
  export default PRODUCT_ACTION_ICONS;